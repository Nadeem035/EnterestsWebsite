<?php echo'<?xml version="1.0" encoding="UTF-8" ?>' ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo base_url();?></loc>
        <priority>1.0</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'lead-management' ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'project-management' ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'about-us' ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'policy' ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'terms' ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'faqs' ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'contact-us' ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'post/unlock-real-estate-business-potential-with-enterests-crm' ?></loc>
        <priority>0.5</priority>
        <changefreq>weekly</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'post/transform-co-working-spaces-with-enterests-crm' ?></loc>
        <priority>0.5</priority>
        <changefreq>weekly</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'post/transform-telemarketing-business-with-enterests-crm' ?></loc>
        <priority>0.5</priority>
        <changefreq>weekly</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'post/effortless-team-collaboration-with-enterests-crm' ?></loc>
        <priority>0.5</priority>
        <changefreq>weekly</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'post/comprehensive-management-solutions-with-enterests-crm' ?></loc>
        <priority>0.5</priority>
        <changefreq>weekly</changefreq>
    </url>
    <url>
        <loc><?php echo base_url().'post/endless-customization-and-features-with-enterests-crm' ?></loc>
        <priority>0.5</priority>
        <changefreq>weekly</changefreq>
    </url>
</urlset>